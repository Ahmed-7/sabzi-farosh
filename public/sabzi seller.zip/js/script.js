var x = 0;

document.getElementById('output-area').innerHTML = x;

function button1() {
  document.getElementById('output-area').innerHTML = ++x;
}

function button2() {
  document.getElementById('output-area').innerHTML = --x;
}
// 2nd btn
var x__1 = 0;

document.getElementById('output-area1').innerHTML = x__1;

function button___1() {
  document.getElementById('output-area1').innerHTML = ++x__1;
}

function button___2() {
  document.getElementById('output-area1').innerHTML = --x__1;
}

//  3rd btn
var x_1 = 0;

document.getElementById('output-area2').innerHTML = x_1;

function btn_1() {
  document.getElementById('output-area2').innerHTML = ++x_1;
}

function btn_2() {
  document.getElementById('output-area2').innerHTML = --x_1;
}

// 4th btn
var y = 0;

document.getElementById('output-area3').innerHTML = y;

function btn1() {
  document.getElementById('output-area3').innerHTML = ++y;
}

function btn2() {
  document.getElementById('output-area3').innerHTML = --y;
}

// 5th btn
var y1 = 0;

document.getElementById('output-area4').innerHTML = y1;

function btn_one() {
  document.getElementById('output-area4').innerHTML = ++y1;
}

function btn_two() {
  document.getElementById('output-area4').innerHTML = --y1;
}

// 6th btn
var y2 = 0;

document.getElementById('output-area5').innerHTML = y2;

function btn__1() {
  document.getElementById('output-area5').innerHTML = ++y2;
}

function btn__2() {
  document.getElementById('output-area5').innerHTML = --y2;
}

//  7th btn
var y4 = 0;

document.getElementById('output-area6').innerHTML = y4;

function button_1() {
  document.getElementById('output-area6').innerHTML = ++y4;
}

function button_2() {
  document.getElementById('output-area6').innerHTML = --y4;
}
//  8th btn
var y5 = 0;

document.getElementById('output-area7').innerHTML = y5;

function button_one() {
  document.getElementById('output-area7').innerHTML = ++y5;
}

function button_two() {
  document.getElementById('output-area7').innerHTML = --y5;
}


//  9th btn
var y6 = 0;

document.getElementById('output-area8').innerHTML = y6;

function button__1() {
  document.getElementById('output-area8').innerHTML = ++y6;
}

function button__2() {
  document.getElementById('output-area8').innerHTML = --y6;
}


//  10th btn 
var y7 = 0;

document.getElementById('output-area9').innerHTML = y7;

function button_add() {
  document.getElementById('output-area9').innerHTML = ++y7;
}

function button_subt() {
  document.getElementById('output-area9').innerHTML = --y7;
}


// 11th btn 
var z = 0;

document.getElementById('output-area-1').innerHTML = z;

function buttonsubt() {
  document.getElementById('output-area-1').innerHTML = --z;
}

function buttonadd() {
  document.getElementById('output-area-1').innerHTML = ++z;
}

//  12th btn
var z1 = 0;

document.getElementById('output-area-2').innerHTML = z1;

function buttonAdd() {
  document.getElementById('output-area-2').innerHTML = ++z1;
}

function buttonSubt() {
  document.getElementById('output-area-2').innerHTML = --z1;
}

//  13th button
var z2 = 0;

document.getElementById('output-area-3').innerHTML = z2;

function button_Add() {
  document.getElementById('output-area-3').innerHTML = ++z2;
}

function button_Subt() {
  document.getElementById('output-area-3').innerHTML = --z2;
}
// 14th btn
var z3 = 0;

document.getElementById('output-area-4').innerHTML = z3;

function button__Add() {
  document.getElementById('output-area-4').innerHTML = ++z3;
}

function button__Subt() {
  document.getElementById('output-area-4').innerHTML = --z3;
}
// 15th btn
var z4 = 0;

document.getElementById('output-area-4').innerHTML = z4;

function button___Add() {
  document.getElementById('output-area-4').innerHTML = ++z4;
}

function button___Subt() {
  document.getElementById('output-area-4').innerHTML = --z4;
}
// 16th btn
var z5 = 0;

document.getElementById('output-area-5').innerHTML = z5;

function button___Add() {
  document.getElementById('output-area-5').innerHTML = ++z5;
}

function button___Subt() {
  document.getElementById('output-area-5').innerHTML = --z5;
}
// 17th btn

var z5 = 0;

document.getElementById('output-area-6').innerHTML = z5;

function button__add() {
  document.getElementById('output-area-6').innerHTML = ++z5;
}

function button__subt() {
  document.getElementById('output-area-6').innerHTML = --z5;
}
// 18th
var z6 = 0;

document.getElementById('output-area-7').innerHTML = z6;

function button___add() {
  document.getElementById('output-area-7').innerHTML = ++z6;
}

function button___subt() {
  document.getElementById('output-area-7').innerHTML = --z6;
}

// 19th btn
var z7 = 0;

document.getElementById('output-area-8').innerHTML = z7;

function button_ad() {
  document.getElementById('output-area-8').innerHTML = ++z7;
}

function button_sub() {
  document.getElementById('output-area-8').innerHTML = --z7;
}

